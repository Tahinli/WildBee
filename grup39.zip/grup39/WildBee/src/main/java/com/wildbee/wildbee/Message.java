package com.wildbee.wildbee;

/**
 * The class to which the message is passed.
 * @since 2022-06
 */
class Message {
    int point;
    String word;
    String game;
    boolean isFinished;
    String finish;

}
